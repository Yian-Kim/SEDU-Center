package main_admin;

public interface IService_AdminMain {

	boolean sLogin(String id, String pw);
	
	
}
