package DTO_Student;

public class DTO_ConsultMax2_S {

	private String requestdate;
	private int cnt;
	
	
	
	
	public String getRequestdate() {
		return requestdate;
	}
	public void setRequestdate(String requestdate) {
		this.requestdate = requestdate;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	
}
