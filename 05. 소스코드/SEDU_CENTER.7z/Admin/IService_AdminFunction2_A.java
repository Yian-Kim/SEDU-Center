package Admin;

public interface IService_AdminFunction2_A {

	void sAttendanceStudentInfoModify();

	void sAttendanceStudentInfoModifySelect(String choice, String startDate, String endDate);

	void sAttendanceStateModify();

	void sAttendanceCourseInfo();

	void sAttendanceCourseView(String select);

	void sAttendanceCourseModify(String choice);

}
