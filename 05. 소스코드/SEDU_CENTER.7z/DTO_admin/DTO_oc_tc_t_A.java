package DTO_admin;

public class DTO_oc_tc_t_A {

	/*
	 * 1. 관리자 – 2. 개설 과정 및 과목 관리– 1. (상세보기)
	 * b. 교사명
	 * 
	 * tblOpenCourse
	 * tblTeacherCourse
	 * tblTeacher 
	 */
	
	private String teacherName; // 개설과정의 해당 교사명

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	
	
	
}
