package DTO_admin;
public class DTO2 {

	private String teacher_seq;
	private String teachername;
	private String coursename;
	private String courseperiod;
	private String subjectname;
	private String period;
	private String roomname;
	private String jungbo;
	
	
	public String getTeachername() {
		return teachername;
	}
	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getCourseperiod() {
		return courseperiod;
	}
	public void setCourseperiod(String courseperiod) {
		this.courseperiod = courseperiod;
	}
	public String getSubjectname() {
		return subjectname;
	}
	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getRoomname() {
		return roomname;
	}
	public void setRoomname(String roomname) {
		this.roomname = roomname;
	}
	public String getTeacher_seq() {
		return teacher_seq;
	}
	public void setTeacher_seq(String teacher_seq) {
		this.teacher_seq = teacher_seq;
	}
	public String getJungbo() {
		return jungbo;
	}
	public void setJungbo(String jungbo) {
		this.jungbo = jungbo;
	}
	
}
